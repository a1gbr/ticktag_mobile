import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthProvider with ChangeNotifier {
  bool _isAuthenticated = false;

  bool get isAuthenticated => _isAuthenticated;

  Future<void> register(String email, String password, String birthDate) async {
    // Simula o processo de registro (substitua por uma chamada de API real)
    await Future.delayed(Duration(seconds: 2));
    if (email.isNotEmpty && password.isNotEmpty && birthDate.isNotEmpty) {
      // Simula um registro bem-sucedido
      _isAuthenticated = true;
      notifyListeners();
    } else {
      throw Exception('Erro no registro. Verifique os dados.');
    }
  }

  Future<void> login(String email, String password) async {
    // Simula a autenticação. Em um caso real, faria uma chamada de API.
    await Future.delayed(Duration(seconds: 2));
    if (email == 'user@example.com' && password == 'password123') {
      _isAuthenticated = true;
      notifyListeners();

      // Armazena os dados da sessão
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('isLoggedIn', 'token');
    } else {
      throw Exception('Falha na autenticação: credenciais inválidas');
    }
  }

  Future<void> checkLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    _isAuthenticated = prefs.getString('isLoggedIn')?.isNotEmpty ?? false;
    notifyListeners();
  }

  Future<void> logout() async {
    _isAuthenticated = false;
    notifyListeners();

    // Remove os dados da sessão
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('isLoggedIn');
  }
}
